//
//  SecondVC.m
//  3DTouchDemoSelf
//
//  Created by 王帅 on 16/8/15.
//  Copyright © 2016年 王帅. All rights reserved.
//

#import "SecondVC.h"

@interface SecondVC ()

@end

@implementation SecondVC
-(instancetype)init{
    @throw [NSException exceptionWithName:@"Singleton" reason:@"SecondVC is a Singleton, please Use shareView to create" userInfo:nil];
}
-(instancetype)initPrivate{
    if (self = [super init]){
    }
        return  self;
}
+(instancetype)shareView{
    static SecondVC * secondVC;
    static dispatch_once_t token;
    if (!secondVC)
        dispatch_once(&token, ^{
          secondVC  = [[SecondVC alloc]initPrivate];
        });
    return secondVC;
}
- (void)viewDidLoad {
    [super viewDidLoad]; 
    self.view.backgroundColor = [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1];
}
@end
