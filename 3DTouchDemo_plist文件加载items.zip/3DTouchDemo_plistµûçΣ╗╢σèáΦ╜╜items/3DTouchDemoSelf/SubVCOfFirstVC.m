//
//  SubVCOfFirstVC.m
//  3DTouchDemoSelf
//
//  Created by 王帅 on 16/8/15.
//  Copyright © 2016年 王帅. All rights reserved.
//

#import "SubVCOfFirstVC.h"

@interface SubVCOfFirstVC ()

@end

@implementation SubVCOfFirstVC
-(instancetype)init{
    @throw [NSException exceptionWithName:@"Singleton" reason:@"SubVCOfFirstVC is a Singleton, please Use shareView to create" userInfo:nil];
}
-(instancetype)initPrivate{
    if (self = [super init]){
    }
    return  self;
}
+(instancetype)shareView{
    static SubVCOfFirstVC * subVC = nil;
    static dispatch_once_t token;
    if (!subVC)
        dispatch_once(&token, ^{
            subVC  = [[SubVCOfFirstVC alloc]initPrivate];
        });
    return subVC;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
}

@end
