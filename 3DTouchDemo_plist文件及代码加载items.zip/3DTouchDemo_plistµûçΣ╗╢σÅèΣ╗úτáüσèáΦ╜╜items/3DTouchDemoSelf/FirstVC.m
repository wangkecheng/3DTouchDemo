//
//  FirstVC.m
//  3DTouchDemoSelf
//
//  Created by 王帅 on 16/8/15.
//  Copyright © 2016年 王帅. All rights reserved.
//

#import "FirstVC.h"
#import "SubVCOfFirstVC.h"
@interface FirstVC ()

@end

@implementation FirstVC
-(instancetype)init{
    //不允许用init方法
    @throw [NSException exceptionWithName:@"Singleton" reason:@"FirstVC is a Singleton, please Use shareView to create" userInfo:nil];
}
-(instancetype)initPrivate{
    //用父类方法初始化
    if (self = [super init]){
    }
    return  self;
}
+(instancetype)shareView{
    static FirstVC * firstVC;
    //GCD方式创建单列
    static dispatch_once_t token;
    if (!firstVC)
    dispatch_once(&token, ^{
      firstVC  = [[FirstVC alloc]initPrivate];
    });
    return firstVC;
}

-(SubVCOfFirstVC *)subVC{
    if (!_subVC) {
        //懒加载创建的对象有且只有一个，保证在pop后push的对象还是同一个
        _subVC  = [SubVCOfFirstVC shareView];
    }
    return  _subVC;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1];
    
    [self createView];
}
-(void)createView{
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 30, 30)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(pushNewView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}
-(void)pushNewView:(UIButton *)btn{
    [self.subVC.view setBackgroundColor:[UIColor whiteColor]];//若UIViewController是一个空的，背景色为透明 则会导致小小的卡顿
    [self.navigationController pushViewController:_subVC animated:YES];
}
@end
