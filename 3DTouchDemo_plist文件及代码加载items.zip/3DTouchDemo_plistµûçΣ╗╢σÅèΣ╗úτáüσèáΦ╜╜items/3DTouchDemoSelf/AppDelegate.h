//
//  AppDelegate.h
//  3DTouchDemoSelf
//
//  Created by 王帅 on 16/8/15.
//  Copyright © 2016年 王帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

