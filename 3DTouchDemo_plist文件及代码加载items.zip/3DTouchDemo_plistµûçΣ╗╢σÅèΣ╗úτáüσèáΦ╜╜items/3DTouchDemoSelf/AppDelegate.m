//
//  AppDelegate.m
//  3DTouchDemoSelf
//
//  Created by 王帅 on 16/8/15.
//  Copyright © 2016年 王帅. All rights reserved.
//

#import "AppDelegate.h"
#import "FirstVC.h"
#import "SecondVC.h"
#import "WSNaviVC.h"
#import "SubVCOfFirstVC.h"
#define BundleID  [NSBundle mainBundle].bundleIdentifier
@interface AppDelegate () 
@property (nonatomic,strong)UIApplicationShortcutItem *currentShortcutItem;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self createNaviItem];

    BOOL result  = YES;
    //系统版本适配
    if ([[UIDevice currentDevice].systemVersion floatValue] < 9.0) {
        return result;
    }
    //判断是否是从shortitem启动的程序
if(launchOptions[@"UIApplicationLaunchOptionsShortcutItemKey"]){
    _currentShortcutItem =launchOptions[@"UIApplicationLaunchOptionsShortcutItemKey"];
    //这个返回值很重要、返回no，不会再调用performActionForShortcutItem这个回调方法
      result = NO;
     }
     //判断是否已经创建了shortitem
    NSArray * item = [UIApplication sharedApplication].shortcutItems;
    if (item.count == 0) {
        //没有则创建Item
        [self createItem];
    }
    
    return result;
}
-(void)createItem{
    //创建默认图标
    UIApplicationShortcutIcon *forthIcon = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeLocation];
    //创建自定图标（似乎不管用）
    //UIApplicationShortcutIcon *forthIcon = [UIApplicationShortcutIcon iconWithTemplateImageName:@"abc.jpeg"];

    //创建选项
    UIApplicationShortcutItem * forthItem = [[UIApplicationShortcutItem alloc]initWithType:[NSString stringWithFormat:@"%@Forth",BundleID] localizedTitle:@"第四个选项" localizedSubtitle:@"还是弹出第三个选项视图" icon:forthIcon userInfo:nil];
    [[UIApplication sharedApplication] setShortcutItems:@[forthItem]];
}

/**
 *  创建标签栏控制器
 */
-(void)createNaviItem{
     WSNaviVC * wsNavi = [[WSNaviVC alloc]init];
    
     _window.rootViewController =wsNavi;
    
    UIImage *image = [[UIImage imageNamed:@""] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIImage *imageSelect = [[UIImage imageNamed:@""] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    FirstVC * firstView = [FirstVC shareView];
    UINavigationController *naviF = [[UINavigationController alloc]initWithRootViewController:firstView];
    naviF.title = @"First";
    naviF.tabBarItem  = [[UITabBarItem alloc]initWithTitle:@"First" image:image selectedImage:imageSelect];
    
    SecondVC * secView = [SecondVC shareView];
    UINavigationController *naviS = [[UINavigationController alloc]initWithRootViewController:secView];
    naviS.title = @"Second";
    naviS.tabBarItem  = [[UITabBarItem alloc]initWithTitle:@"Second" image:image selectedImage:imageSelect];
    //将UINavigationController添加到标签栏控制器中
    wsNavi.viewControllers = @[naviF,naviS];

    //设置默认选中UINavigationController
    wsNavi.selectedViewController = [wsNavi.viewControllers objectAtIndex:1];
  }
-(void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler{
     //处理点击事件
    [self handleItem:shortcutItem];
}
-(void)handleItem:(UIApplicationShortcutItem *)shortcutItem{
    
    WSNaviVC *wsNavi = (WSNaviVC *)_window.rootViewController;
    //判断3DTouch点击的选项
    if ([shortcutItem.type isEqualToString:@"UIApplicationShortcutItemTypeFirst"]) {
        //第一项就将改变选中项为第0项
        wsNavi.selectedViewController = [wsNavi.viewControllers objectAtIndex:0];
    }
    if ([shortcutItem.type isEqualToString:@"UIApplicationShortcutItemTypeSecond"]) {
        //第二项就将改变选中项为第1项
        wsNavi.selectedViewController = [wsNavi.viewControllers objectAtIndex:1];
    }
    
    // 或判断后面的是第四个选项，为了方便，第四项和第三项弹出的视图相同
    if ([shortcutItem.type isEqualToString:@"UIApplicationShortcutItemTypeThird"]||[shortcutItem.type isEqualToString:[NSString stringWithFormat:@"%@Forth",BundleID]]){
        //第三项就将改变当前视图为第0个barItem弹出的界面
        wsNavi.selectedViewController = [wsNavi.viewControllers objectAtIndex:0];
        SubVCOfFirstVC * subVC =  [SubVCOfFirstVC shareView];
        subVC.view.backgroundColor = [UIColor whiteColor];
        [wsNavi.selectedViewController pushViewController:subVC animated:YES];
    }
}
-(void)applicationDidBecomeActive:(UIApplication *)application{
      if(!_currentShortcutItem)
          return;
    [self handleItem:_currentShortcutItem];
    _currentShortcutItem = nil;
    
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationWillTerminate:(UIApplication *)application {

}
@end
